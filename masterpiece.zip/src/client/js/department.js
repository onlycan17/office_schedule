const btn_update = document.getElementById('btn_update');

const test = () => {
    console.log('test~~!!!!');
}


btn_update.addEventListener("click",test);